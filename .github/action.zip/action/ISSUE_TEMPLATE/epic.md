---
name: Epic
labels: Epic
about: Create a new Epic
---

**Description**
A clear and concise description of what the feature is about.

**Additional resources**
Some examples of resources that might be added here
* Problem statement definition
* Proposed workflow
* Link to the feedback/context/motivation/research work
* Mockups and or designs

**Feature breakdown**
It includes:
- [ ] First issue #1
- [ ] Another issue (#2)

Good to have:
- [ ] First issue #1
- [ ] Another issue (#2)
